package com.example.elearning.repository;

import com.example.elearning.entity.SessionBooking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SessionBookingRepository extends JpaRepository<SessionBooking, Long> {}
