package com.example.elearning.controller;

import com.example.elearning.entity.SessionBooking;
import com.example.elearning.repository.SessionBookingRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import org.springframework.web.bind.annotation.CrossOrigin;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/session-booking")
public class SessionBookingController {

    private final SessionBookingRepository sessionBookingRepository;

    public SessionBookingController(SessionBookingRepository sessionBookingRepository) {
        this.sessionBookingRepository = sessionBookingRepository;
    }

    @GetMapping("/{userId}")
    public ResponseEntity<List<SessionBooking>> getBookingsByUserId(@PathVariable Long userId) {
        List<SessionBooking> bookings = sessionBookingRepository.findAll().stream()
                .filter(booking -> booking.getUser().getId().equals(userId))
                .toList();
        return ResponseEntity.ok(bookings);
    }

    @PostMapping
    public ResponseEntity<?> createBooking(@RequestBody SessionBooking booking) {
        sessionBookingRepository.save(booking);
        return ResponseEntity.ok("Session booked successfully");
    }
}
