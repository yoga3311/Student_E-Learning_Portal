package com.example.elearning.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.elearning.entity.Admin;
import com.example.elearning.entity.AuthenticationRequest;
import com.example.elearning.service.AdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private AdminService adminService;

    @PostMapping("/login")
    public ResponseEntity<String> createAdminAuthenticationToken(@RequestBody AuthenticationRequest authenticationRequest) {
        try {
            // Attempt to authenticate the admin
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(authenticationRequest.getEmail(), authenticationRequest.getPassword())
            );

            // Check if admin exists and password matches
            Admin admin = adminService.getAdminByEmail(authenticationRequest.getEmail())
                    .orElseThrow(() -> new BadCredentialsException("Admin not found with email: " + authenticationRequest.getEmail()));

            // Compare the provided password with the stored password
            if (!(authenticationRequest.getPassword().equals(admin.getPassword()))) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(
                        "Incorrect password for email: " + authenticationRequest.getEmail() +
                        ". Received password: " + authenticationRequest.getPassword() +
                        ". Correct password is: " + admin.getPassword()
                );
            }

            // Authentication successful
            return ResponseEntity.ok("Admin login successful");

        } catch (BadCredentialsException e) {
            // Check if the issue is due to email or password
            if (adminService.getAdminByEmail(authenticationRequest.getEmail()).isEmpty()) {
                // Email not found
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(
                        "Admin not found with email: " + authenticationRequest.getEmail()
                );
            } else {
                // Password is incorrect
                Admin admin = adminService.getAdminByEmail(authenticationRequest.getEmail()).get();
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(
                        "Incorrect password for email: " + authenticationRequest.getEmail() +
                        ". Received password: " + authenticationRequest.getPassword() +
                        ". Correct password is: " + admin.getPassword()
                );
            }
        }
    }
}
