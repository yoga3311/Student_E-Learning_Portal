package com.example.elearning.controller;

import java.util.List;

import com.example.elearning.entity.Contact;
import com.example.elearning.repository.ContactRepository;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/contact")
public class ContactController {

    private final ContactRepository contactRepository;

    public ContactController(ContactRepository contactRepository) {
        this.contactRepository = contactRepository;
    }

    @PostMapping
    public ResponseEntity<?> createContactMessage(@RequestBody Contact contact) {
        contactRepository.save(contact);
        return ResponseEntity.ok("Contact message sent successfully");
    }

    @GetMapping
    public ResponseEntity<List<Contact>> getAllContacts() {
        List<Contact> contacts = contactRepository.findAll();
        return ResponseEntity.ok(contacts);
    }

    @GetMapping("/count")
    public ResponseEntity<?> getContactCount() {
        long count = contactRepository.count();
        return ResponseEntity.ok(count);
    }
}
